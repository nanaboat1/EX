
package exam;

import java.util.Random; // Random Number Generator Class.
import java.lang.Math; // The Math Class.
import java.lang.String; // The String Class.


public class Circle implements Shape {
	
	
	
	private int ID = 0; // ID of the Object.
	
	private double radius; // radius of the shape. 
	
	private double circumference; // circumference of the shape
	
	private double area; // Area of the shape 
	
	private String Color; //
	
	
	public Circle(double _radius, int id, String _Color) {
		
		this.setRadius(_radius);
		this.ID = id;
		this.Color = _Color;
		
		this.setArea();
		this.setCircumference();
		
	} 
	
	
	

	@Override
	public String getKind() {
		return "Circle";
		
	}

	@Override
	public String getDetailString() {
		
		String str = "Kind of Shape : " + this.getKind() + "\n";
		
		str += "ID : " + this.getID() + "\n";
		
		str += "Radius : " + this.getRadius() + "\n";
		
		str += "Area : " + this.getArea() + "\n";
		
		str += "Circumference : " + this.getCircumference() + "\n";
		
		return str; 
 	}

	@Override
	public String getID() {
		
		return Integer.toString(this.ID); 
	}


	/**
	 * @return the area
	 */
	public double getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea() {
		this.area = Math.PI * Math.pow(this.getRadius(),2.0);
	}

	/**
	 * @return the circumference
	 */
	public double getCircumference() {
		return circumference;
	}


	/**
	 * @param circumference the circumference to set
	 */
	public void setCircumference() {
		this.circumference = 2* Math.PI * this.getRadius();
	}


	/**
	 * @return the radius
	 */
	public double getRadius() {
		return radius;
	}

	
	/**
	 * @param radius the radius to set
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}

}
