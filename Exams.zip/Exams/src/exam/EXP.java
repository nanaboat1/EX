package exam;

// Source : https://zetcode.com/gfx/java2d/shapesandfills/
// Source : https://www.codegrepper.com/code-examples/java/how+to+create+a+draw+Rectangle+in+java


import java.io.FileNotFoundException;
import java.io.FileReader;// For file handling
import java.io.IOException; // Exception handling 
import java.util.ArrayList; // ArrayList Class
import java.util.List; // List Class
import java.io.BufferedReader;
import java.lang.String; 
import java.util.regex.*;
import java.util.ArrayList;
import java.util.List;

import java.util.Random;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.awt.Canvas;

// Libraries for Parsing txt Files



public class EXP extends JPanel {
	
	public static Object test;
	
	/** @return  the The ArrayList of Shapes*/
	public static List<Shape> read_file() throws IOException { 
		
		List<Shape> data = new ArrayList<Shape>(); // To Hold Collection of Objects
		
		BufferedReader reader; 
		Random rand = new Random();
		
	
			reader = new BufferedReader(new FileReader("/Users/nanaboateng/Downloads/shark.txt"));
			
			String line;
			
				line = reader.readLine();
			
			int i =102;
			int p = 0;
			
			while(p <= 94 && line != null ) { 
				
				line = reader.readLine();
				
				if (line.charAt(0) == 'c' ) { // when its a circle 
					
					data.add(new Circle(rand.nextDouble()%14.0, i, "yellow"));
					
					line = "";
					
					
				} else if (line.charAt(0) == 's') { // when its a square
					data.add(new Square(rand.nextDouble()%10.0, i, "green"));
					line = "";
					
				} else if (line.charAt(0) == 'r' ) { // when its a rectangle
					data.add(new Rectangle(rand.nextDouble()%9.0, rand.nextDouble()%10.0, i, "black"));
					line = "";
				} else {
					data.add(new Triangle(rand.nextDouble()%9.0, rand.nextDouble()%10.0,rand.nextDouble()%10.0, i, "red"));
					line = "";
				}
				
				i++; // counter for the id
				p++; //counter for the file reading 
			}
			
			reader.close();
			
			
			
		
		return data;
	}
		
	/** 
	 * @param g Graphics to be drawn 
	 * @param p Shape to be drawn */
	public  void draw( Graphics g) {
		
		
		
		  Toolkit t=Toolkit.getDefaultToolkit();  
	       Image i=t.getImage("");  
	        g.drawImage(i, 120,100,this); 
		
	
		
		if ( ((Circle) test).getKind() == "Circle") {
			
			g.drawOval(100, 100, (int) ((Circle) test).getRadius(), (int) ((Circle) test).getRadius());
			
		} else if ( ((Square) test).getKind() == "Square") {
			
			g.drawRect(100, 100,(int) ((Square) test).getLength(), (int) ((Square) test).getLength());
			
		} else /*( ((Rectangle) p).getKind()== "Rectangle")*/ {
			
			g.drawRect(100, 100,(int) ((Rectangle) test).getLength(),(int) ((Rectangle) test).getWidth());
		
		}
		
	}
	
	
	

		
		
	
	public static void main(String[] args) throws IOException  {
		
		
		List<Shape> data = new ArrayList<Shape>();
		
		data = read_file(); // Read the File 
		
		// Create A Frame
		JFrame frame = new JFrame();
		Canvas m = new Canvas();
		frame.setTitle("EXAMS");
		frame.add(m);
		
		
		
		
		// Add a Component to the frame
		frame.setSize(600, 400);
		frame.setVisible(true);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		for ( int i=0; i< 90; i++ ) {
			
			System.out.println(data.get(i).getDetailString());
		}
		
		
		
		
		
		
	
		
			
		
			
			
			
		
		
			
			
			
			
			
			
			
		
		
		
		

	}

}
