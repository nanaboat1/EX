package exam;

import java.util.Random; 

public class Rectangle implements Shape {
	
	
	private int ID; 
	
	private double length; 
	
	private double width; 
	
	private double Area; 
	
	private double Perimeter; 
	
	private String _Color; 
	
	
	public Rectangle(double _length, double _width, int id, String Color ) { 
		
		this.setLength(_length);
		this.setWidth(_width);
		this.ID = id;
		this._Color  =Color;
		this.setArea();
		this.setPerimeter();
		

		
	}
	

	@Override
	public String getKind() {
		
		return "Rectangle"; 
	}

	@Override
	public String getDetailString() {
		
		String str = " Kind of Shape " + this.getKind() + "\n";
		
		str += "Color" + this._Color + "\n";
		
		str += "ID :" + this.getID() + "\n";
		
		str += "Length : " + this.getLength() + "\n"; 
		
		str += "Width : " + this.getWidth() + "\n";
		
		str += "Area : " + this.getArea() + "\n";
		
		str += "Perimeter :" + this.getPerimeter() + "\n"; 			
		return str;
	}

	@Override
	public String getID() {
		
		return Integer.toString(this.ID);
	}

	/**
	 * @return the length
	 */
	public double getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(double length) {
		this.length = length;
	}

	/**
	 * @return the width
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(double width) {
		this.width = width;
	}

	/**
	 * @return the area
	 */
	public double getArea() {
		return Area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea() {
		Area = this.getLength() * this.getWidth();
	}

	/**
	 * @return the perimeter
	 */
	public double getPerimeter() {
		return Perimeter;
	}

	/**
	 * @param perimeter the perimeter to set
	 */
	public void setPerimeter() {
		
		Perimeter = 2* (this.getLength() + this.getWidth());
	}

}
