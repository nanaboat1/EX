package exam; // The Package of Shape. 

public interface Shape {
	
	/** @return The Kind and ID of the Shape */
	public String  toString(); 
	
	/** @return Return the Kind of Shape */
	public String getKind();  

	/** @return  The Details of that Shape */
	public String getDetailString(); 
	
	/** @return the ID of the Shape */
	public String getID(); //  
	

}
