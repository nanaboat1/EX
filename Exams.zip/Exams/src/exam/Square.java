package exam;


public class Square implements Shape {
	
	
	
	
	private int ID; // ID for object. 
	
	private double length; 
	
	private double Area; 
	
	private double Perimeter; 
	
	private String _Color; 
	
	
	public Square(double _length, int id, String Color) { 
		
		this.setLength(_length);
		this.ID = id;
		this._Color = Color;
		this.setArea();
		this.setPerimeter();
			
	}
	
	
	@Override
	public String getKind() {
		
		return "Square"; 
	}

	@Override
	public String getDetailString() {
		
		String str  = " Shape Kind : " + this.getKind() + "\n";
		
		str += "Color : " + this._Color + "\n";
		
		str += " ID : " + this.getID() + "\n";
		
		str += " Length : " + this.getLength() + "\n";
		
		str += " Perimeter : " + this.getPerimeter() + "\n";
		
		str += " Area : " + this.getArea() + "\n";
		
		return str; 
	}

	@Override
	public String getID() {
		
		return Integer.toString(this.ID);
	}

	/**
	 * @return the length
	 */
	public double getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(double length) {
		this.length = length;
	}

	/**
	 * @return the area
	 */
	public double getArea() {
		return Area;
	}

	/**
	 *  the area to set
	 */
	public void setArea() {
		this.Area = this.getLength() * this.getLength();
		
	}

	/**
	 * @return the perimeter
	 */
	public double getPerimeter() {
		
		return Perimeter;
	}

	/**
	 * @param perimeter the perimeter to set
	 */
	public void setPerimeter() {
		
		this.Perimeter = 4 * this.getLength();
	}

}
