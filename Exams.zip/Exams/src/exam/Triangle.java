package exam;

import java.util.Random; // The Random Class generator.

public class Triangle implements Shape {
	
	
	private int ID; 
	
	private double s_a; // side a of triangle
	
	private double s_b; // side b pf triangle
	
	private double s_c; // side c of triangle
	
	private double Area; 
	
	private double Perimeter; 
	
	private String _color; 
	
	
	public Triangle(double sideA, double sideB, double sideC, int _id, String Color ) {
		
		
		// Set the Data Values of the Class	
		this.setS_a(sideA);
		this.setS_b(sideB);
		this.setS_c(sideC);
		this.setArea();
		this.setPerimeter();
		this.set_color(Color);
		
	}
	
	
	


	@Override
	public String getKind() {
		
		return "Triangle";
	}

	@Override
	public String getDetailString() {
		
		String str = " Kind of Shape : " + this.getKind() + "\n";
		
		str += "Color : " + this.get_color() + "\n";
		
		str += "ID :" + this.getID() + "\n";
		
		str += "Side A : " + this.getS_a() + "\n"; 
		
		str += "Side B : " + this.getS_b() + "\n";
		
		str += "Side C : " + this.getS_c() + "\n";
		
		str += "Area : " + this.getArea() + "\n";
		
		str += "Perimeter :" + this.getPerimeter() + "\n"; 			
		return str;
	}

	@Override
	public String getID() {
		
		return Integer.toString(this.ID);
	}

	/**
	 * @return the s_a
	 */
	public double getS_a() {
		return s_a;
	}

	/**
	 * @param s_a the s_a to set
	 */
	public void setS_a(double s_a) {
		this.s_a = s_a;
	}

	/**
	 * @return the s_b
	 */
	public double getS_b() {
		return s_b;
	}

	/**
	 * @param s_b the s_b to set
	 */
	public void setS_b(double s_b) {
		this.s_b = s_b;
	}

	/**
	 * @return the s_c
	 */
	public double getS_c() {
		return s_c;
	}

	/**
	 * @param s_c the s_c to set
	 */
	public void setS_c(double s_c) {
		this.s_c = s_c;
	}

	/**
	 * @return the area
	 */
	public double getArea() {
		return Area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea() {
		
		Area = 0.5 * s_b * s_c;
		
		
	}

	/**
	 * @return the perimeter
	 */
	public double getPerimeter() {
		return Perimeter;
	}

	/**
	 * @param perimeter the perimeter to set
	 */
	public void setPerimeter() {
		
		Perimeter = s_a + s_b + s_c; 
		
		
	}












	/**
	 * @return the _color
	 */
	public String get_color() {
		return _color;
	}












	/**
	 * @param _color the _color to set
	 */
	public void set_color(String _color) {
		this._color = _color;
	}

}
