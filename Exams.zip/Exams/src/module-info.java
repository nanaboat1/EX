module exams {
	requires java.xml;
	requires java.desktop;
}